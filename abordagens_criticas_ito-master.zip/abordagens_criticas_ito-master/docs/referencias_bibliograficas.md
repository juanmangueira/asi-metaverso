# **Referências Bibliográficas**
BERNADINELLI, I.; CANDIDO, S. E. A.; TONELLI, M. J. Neoliberalismo e envelhecimento ativo: O papel dos programas empresariais de preparação para aposentadoria. **Revista de Administração
Mackenzie**, São Paulo, v.24, n.1, p. 1–27, 2023. Disponível em: <https://doi.org/10.1590/1678-6971/eRAMG230168.pt>. Acesso em: 17 de jan. de 2025.

FOURNIER, V.; GREY, C. Hora da verdade: condições e prospectos para os estudos críticos de gestão. _In_: CALDAS, M. P. (coord.); BERTERO, C. O. (coord.). **Teoria das Organizações**. São Paulo: Atlas, 2007. p. 335-360.

VIEIRA, M. M. F; CALDAS, M. P. Teoria crítica e pós-modernismo: principais alternativas à hegemonia funcionalista. _In_: CALDAS, M. P. (coord.); BERTERO, C. O. (coord.). **Teoria das Organizações**. São Paulo: Atlas, 2007. p. 291-311.